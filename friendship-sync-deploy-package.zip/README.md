# Friendship Sync Test

🌼 一个用于测试你与朋友之间“友情同步值”的小测试页面！

## 🧷 使用说明

- 打开本仓库
- 上传完成后，进入 Settings → Pages
- 选择 main 分支，目录选 /root，保存
- 几秒后你就会看到上线网址！

> 默认页面入口是 `index.html`

祝你和馄饨友情值满分 💘
